/******************************************************************************************/
import express from "express";                          // Express Server
import cors from "cors";                                // CORS
import pg from "pg";                                    // Database Connector (PostgreSQL)
import bodyParse from "body-parser";                    // Request Body Parser
import bcrypt from "bcrypt";                            // Encryption for Hash and Compare
import GoogleStrategy from "passport-google-oauth2";    // Google OAuth
import session from "express-session";                  // Session Keeper
import { config as envConfig } from "dotenv";           // Environment Variable

import { 
  GET_AGENT_WITH_REVIEWS,
  GET_ALL_AGENTS,
  GET_POSTS,
  POST_AGENT_REVIEW,
  POST_CONFESSION
 } from "./SQLStatements.js";

envConfig();                                            // for environment variables
const app = express();                                  // Server Setup
const PORT = Number(process.env.SERVER_PORT);           // Port Number

app.use(express.json());                                // Similar to Body Parse but for handling the Axios default
app.use(express.urlencoded({ extended: true }));        // Similar to Body Parse but for handling the Axios default

app.use(bodyParse.urlencoded({extended:true}));         // Body Parser
app.use(cors({ origin: process.env.CLIENT_URL }));      // Allow from client server
/******************************************************************************************/

const { Pool } = pg;

const db = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT
});

db.connect();

app.get("/allAgents", async (req, res) => {
  try {
    const result = await db.query(GET_ALL_AGENTS);
    console.log(result.rows);
    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching agents: ", err.message);
    res.status(500).json({error: "Database error, cannot fetch agents"});
  }
});

app.get("/agent/:id", async (req, res) => {
  const agentId = req.params.id;

  try {
    const result = await db.query(GET_AGENT_WITH_REVIEWS,
    [agentId]);

    if (result.rows.length===0) {
      console.log("Agent: " + agentId + " does not exist");
      return res.status(404).json({error:"Agent does not exist!"});
    } else {
      console.log(result.rows[0]);
      return res.json(result.rows[0]);
    }
  } catch (err) {
    console.error("Error fetching agent: ", err.message);
    return res.status(500).json({error: "Database error, cannot fetch this agent"});
  }

}); 

/*
app.get("/allAgents", async (req, res) => {
    res.status(401).json({error: "Database error."});
});
*/

app.get("/posts", async (req, res) => {
  const MAX_LIMIT = 10;
  const limit = Math.min(parseInt(String(req.query.limit ?? 10), 10) || 10, MAX_LIMIT);
  const cursor = req.query.cursor ? Number(req.query.cursor) : null; // last id you saw

  try {
    const { rows } = await db.query(GET_POSTS,
      [cursor, limit]
    );

    // Check if length has more than the limit, set that to hasMore
    const hasMore = rows.length > limit;                          
    
    // Slice the items upto the 10th
    const items = hasMore ? rows.slice(0, limit) : rows;            

    // Move Cursor to the last
    const endCursor = hasMore ? items[items.length - 1].id : null;

    res.json({ items, endCursor, hasMore });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }

});

app.get("/post/:id", async (req,res) => {

  const id = Number(req.params.id);

  try {
    const response = await db.query(GET_POST_BY_ID, [id]);
    if (response.rowCount > 0) {
      res.status(201).json(response.rows[0]);
    } else {
      res.status(404).json({error: "This post does not exist!"});
    }
  } catch (err) {
    res.status(500).json({error: "Internal Server Error"});
  }

});



app.post("/createReview/:id", async (req, res) => {
  const agentId = req.params.id;
  const { username, title, content, created_at } = req.body;

  if (!agentId || !username || !title || !content || !created_at) {
    return res.status(400).json({ error: "Incomplete fields!" });
  }

  try {
    const response = await db.query(POST_AGENT_REVIEW,
      [agentId, username, title, content, created_at]
    );

    if (response.rowCount > 0) {
      return res.status(201).json(response.rows[0]);
    }
    return res.status(500).json({ error: "Insert failed." });
  } catch (err) {
    return res.status(500).json({ error: "Internal error with database" });
  }
});

app.post("/posts", async (req, res) => {

  const { title, content, author, date } = req.body;

  if (!title || !content || !author || !date) {
    return res.status(400).json({ error: "Incomplete fields!" });
  }

  try {
    const result = await db.query(
      POST_CONFESSION,
      [title, content, author, date]
    );

    if (result.rowCount > 0) {
      return res.status(201).json(result.rows[0]);
    }
    return res.status(500).json({ error: "Insert failed." });
  } catch (err) {
    return res.status(500).json({ error: "Internal error with database" });
  }
});


app.listen(PORT, ()=>{
    console.log("Server is listening on port: " + PORT);
});