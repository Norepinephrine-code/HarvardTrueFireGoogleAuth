let agentArray = [
  { id: 1, name: "Abad, Alexander Co", reviewCount: 2 },
  { id: 2, name: "Ramos, Hadriel H.", reviewCount: 5 },
  { id: 3, name: "Kim, Ashley P.", reviewCount: 0 },
  { id: 4, name: "Chen, Marcus L.", reviewCount: 12 },
  { id: 5, name: "Garcia, Sofia R.", reviewCount: 8 },
  { id: 6, name: "Patel, Rohan S.", reviewCount: 1 },
  { id: 7, name: "Johnson, Maya T.", reviewCount: 23 },
  { id: 8, name: "Nguyen, David K.", reviewCount: 4 },
  { id: 9, name: "O'Connor, Liam J.", reviewCount: 16 },
  { id: 10, name: "Zhang, Wei", reviewCount: 99 },
  { id: 11, name: "Smith, Olivia J.", reviewCount: 7 },
  { id: 12, name: "Hernandez, Carlos M.", reviewCount: 3 },
  { id: 13, name: "Lee, Hannah S.", reviewCount: 11 },
  { id: 14, name: "Brown, Ethan A.", reviewCount: 6 },
  { id: 15, name: "Santos, Maria L.", reviewCount: 14 },
  { id: 16, name: "Wilson, Noah R.", reviewCount: 9 },
  { id: 17, name: "Park, Ji-woo", reviewCount: 2 },
  { id: 18, name: "Martinez, Elena V.", reviewCount: 5 },
  { id: 19, name: "Davis, Chloe B.", reviewCount: 10 },
  { id: 20, name: "Torres, Gabriel D.", reviewCount: 18 }
];

export default agentArray;
