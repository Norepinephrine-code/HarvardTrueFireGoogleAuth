import React from "react";
import "../styles/homePage.css";
import HomeCard from "../components/HomeCard";

export function HomePage() {
  return (
    <div className="home-page d-flex flex-column justify-content-center align-items-center text-center">
      <HomeCard />
    </div>
  );
}

export default HomePage;
